export enum TipoDocumento {
    CPF = 'Cadastro de Pessoas Física',
    RG = 'Registro Geral',
    Passaporte = 'Passaporte'
}