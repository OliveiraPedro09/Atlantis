export default interface Impressor {
    imprimir(): string
}