export default interface Prototipo {
    clonar(): Prototipo
}