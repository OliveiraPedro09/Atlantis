export default interface Construtor<T> {
    construir(): T
}