export default interface Menu {
    mostrar(): void
}